#!/bin/bash

# Determine if this scipt is run by root user ----------------------------------
function isRoot {
	if [ $(id -u) != '0' ] ; then
		echo "ERROR => Run this script as root" >> $LOGGER
		return 1
	fi	
	
	return 0
}

# Show usage -------------------------------------------------------------------
function usage {
	echo "Usage: batch_upgrade.sh CurrentAgentLocation AgentInstallerLocation" >> $LOGGER
  	exitOnFailure
}

# Verify given arguments -------------------------------------------------------
function verifyArguments {
	if [ -z "$AGENT" ]
	then
  		echo "Current agent location not provided" >> $LOGGER 
  		usage
	fi	
	
	if [ -z "$INSTALLERLOCATION" ]
	then
  		echo "Installer location not provided" >> $LOGGER
  		usage
	fi
}

# Given volume name retrieve its corresponding filesystem -------------------
function getFileSystem {
        TMP_FILESYSTEM=""
        fname=df-tmp
        if [ -f $fname ]
        then
                `rm $fname`
        fi

        `df $TMP_VOLUME > $fname 2>> $LOGGER`

        exec<$fname
        count=0
        while read line
        do
                count=`expr $count + 1`
                
                if [ "$count" == "2" ]
                then    
                        splitLine=(`echo $line | tr ' ' '\n'`)
                        TMP_FILESYSTEM=${splitLine[0]}
                fi
        done

        if [ -f $fname ]
        then
                `rm $fname`
        fi
}

# Retrieve current volume name where existing agent is installed ------------
function getInstallVolume {
	echo "" >> $LOGGER
	echo "Finding current volume..." >> $LOGGER
        #
	# Step 1: Find out filesystem for root volume
        #
        TMP_VOLUME="/"
        getFileSystem
        FILESYSTEM=$TMP_FILESYSTEM
        echo "$TMP_VOLUME => $FILESYSTEM" >> $LOGGER

        #
        # Step 2: 
        #
        src="/Volumes"
        IFS=$'\n'
        for dir in `ls "$src/"`
        do
				firstChar=`(echo $dir | head -c 1)`
				if [ "$firstChar" == "." ]
				then
					echo "$dir should be ignored" >> $LOGGER
					continue
				fi
                TMP_VOLUME="$src/$dir"
                getFileSystem
                echo "$TMP_VOLUME => $TMP_FILESYSTEM" >> $LOGGER
                if [ "$FILESYSTEM" == "$TMP_FILESYSTEM" ]
                then
                        VOLUME=$TMP_VOLUME
                        break
                fi
        done

        #
        # Step 3
        #
        echo "Current volume is $VOLUME" >> $LOGGER
}	

# Backup agent config, log files, and pending submit data ----------------------
function backup {
	echo "" >> $LOGGER
	echo "Backing up the needed data" >> $LOGGER
	
	`mkdir $BACKUP 2>> $LOGGER` 
	`cp $AGENT/etc/nagent.conf $BACKUP 2>> $LOGGER`
	`cp -rf /var/log/N-able/N-agent $BACKUP 2>> $LOGGER`
#	`cp -rf $AGENT/home/nagent/CMData $BACKUP 2>> $LOGGER`
#	`cp -rf $AGENT/home/nagent/CMSetting $BACKUP 2>> $LOGGER`
}

# Uninstall existing agent -----------------------------------------------------
function uninstall {
	echo "" >> $LOGGER
	echo "Uninstalling the agent" >> $LOGGER
	
	echo "$AGENT/usr/sbin/uninstall-nagent yes" >> $LOGGER
	$AGENT/usr/sbin/uninstall-nagent yes >> $LOGGER
}

# Install new agent package and restored backed up data ------------------------ 
function install {
	echo "" >> $LOGGER
	echo "Installing new agent" >> $LOGGER
	
	cd $INSTALLERLOCATION
	echo "sudo installer -pkg $PACKAGE -target $VOLUME" >> $LOGGER
	sudo installer -pkg $PACKAGE -target "$VOLUME" >> $LOGGER

	if [ $? != 0 ] ; then		
		return 1
	fi
	
	echo "" >> $LOGGER
	echo "Restoring backup data" >> $LOGGER
	`cp $BACKUP/nagent.conf $AGENT/etc/nagent.conf 2>> $LOGGER`
	`cp -rf $BACKUP/N-agent /var/log/N-able/ 2>> $LOGGER`
#	`cp -rf $BACKUP/CMData $AGENT/home/nagent/ 2>> $LOGGER`
#	`cp -rf $BACKUP/CMSetting $AGENT/home/nagent/ 2>> $LOGGER`
	
	`chown root /Library/LaunchDaemons/com.n-able.agent-macosx.* 2>> $LOGGER`
	
	`rm -rf $BACKUP 2>> $LOGGER`
	return 0
}

# Starts agent service ---------------------------------------------------------
function startAgent {
	echo "" >> $LOGGER
	echo "Start agent service" >> $LOGGER
	
	sudo launchctl load /Library/LaunchDaemons/com.n-able.agent-macosx.plist 2>> $LOGGER
}

# Do cleanup work and exit the script with error code --------------------------
function exitOnFailure {
	`rm -rf backup`
	
	echo "Agent upgrade failed" >> $LOGGER
	echo "======================================= END UPGRADE ==============================" >> $LOGGER
	exit 1
}

LOGGER="/tmp/nagent-upgrade.log"
echo "" >> $LOGGER
echo "================= START UPGRADE $(date) =================" >> $LOGGER

# Step 1: Ensure this script is run by root user -------------------------------
isRoot
if [ $? != 0 ] ; then
	exitOnFailure
fi

# Step 2: Verify variables used in script
AGENT=$1
INSTALLERLOCATION=$2
PACKAGE="agent-macosx.pkg"
BACKUP="/tmp/nagent-upgrade-backup"
verifyArguments

echo "Using following variables" >> $LOGGER
echo "AGENT=$AGENT" >> $LOGGER
echo "INSTALLERLOCATION=$INSTALLERLOCATION" >> $LOGGER
echo "PACKAGE=$PACKAGE" >> $LOGGER
echo "BACKUP=$BACKUP" >> $LOGGER

# Ste 3: Do not proceed if failed to get installed agent volume ----------------
TMP_VOLUME=""
TMP_FILESYSTEM=""
FILESYSTEM=""
VOLUME=""
getInstallVolume
if [ -z $VOLUME ] ; then
	echo "ERROR => Could not find installed agent volume" >> $LOGGER
	exitOnFailure
fi

# Step 4: Back up needed data and uninstall existing agent ---------------------
backup
uninstall

#Step 5: Install new agent and start the agent binary -------------------------
install
if [ $? != 0 ] ; then
	echo "ERROR => Failed to install new agent" >> $LOGGER
	exitOnFailure
fi

startAgent

echo "" >> $LOGGER
echo "Upgrade successfull" >> $LOGGER
echo "======================================= END UPGRADE ==============================" >> $LOGGER
