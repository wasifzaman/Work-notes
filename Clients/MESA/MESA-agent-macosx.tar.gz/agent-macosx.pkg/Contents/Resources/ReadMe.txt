Starting and stopping the agent
===============================
The Mac OS X agent is started automatically during the system boot process. The operating system will ensure that the agent is restarted automatically in the event that it crashes or is killed. If necessary, it can be started and stopped manually using the launchctl utility.

To start or stop the agent processes using the launchctl utility, follow the following procedure:

As an administrator, open a terminal window and run the launchctl command:

   sudo launchctl

Enter your login password when prompted.

To start the agent, enter the following:

   load /Library/LaunchDaemons/com.n-able.agent-macosx.plist

To stop the agent, enter the following:

   unload /Library/LaunchDaemons/com.n-able.agent-macosx.plist

Quit launchctl by typing control-d.


Viewing agent logs
==================
The agent writes logging information to "/var/log/N-able/N-agent/nagent.log". The operating system will rotate this log daily and will retain only the previous five days of log files.


Uninstalling the agent
======================
To uninstall the agent, log in as an administrator user. Open a terminal window and run the following command:

sudo /Applications/N-agent/usr/sbin/uninstall-nagent

NOTE: Uninstalling the agent by dragging the N-agent application folder to the trash is not recommended. This method of uninstalling the agent will fail if the agent is running and will not remove the launchd service startup files from /Library/LaunchDaemons. 
