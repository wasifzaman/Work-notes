#!/bin/bash

#Get Options
while getopts 'k:c:i:s:p:a:x:r:P:T:' OPTION
do
        case $OPTION in
        k)      ACTIVATE_KEY=$OPTARG
                ;;
        c)      CNAME=$OPTARG
                ;;
        i)      CID=$OPTARG
                ;;
        s)      SERVER=$OPTARG
                ;;
        p)      PROTOCOL=$OPTARG
                ;;
        a)      PORT=$OPTARG
                ;;
        x)      PROXY=$OPTARG
                ;;
	P)	package_file=$OPTARG
		;;
	T) 	tgt_vol=$OPTARG
	esac
done

#Default Values for port and protocol
if [ -z $PORT ] ; then 
	PORT=443
fi
if [ -z $PROTOCOL ] ; then 
	PROTOCOL=https
fi

usage() {
	cat <<-EOF
	To install with an activation key, retrieved from the central server
	sudo sh batch-install.sh -P <package file> -T <target volume> -k <activation key>
	
	To install with a Customer Access Code
	sudo sh batch-install.sh -P <package file> -T <target volume> -s <server endpoint ip/fqdn> -i <customer access code>
	
	To install with a Customer Name
	sudo sh batch-install.sh -P <package file> -T <target volume> -s <server endpoint ip/fqdn> -c <customer name>
	NB:  Customer name may need to be quoted if it contains spaces or shell meta-characters
	
	Other Flags for the Customer Specific Installer
	-p Specify the protocol for the agent to use (default https)
	-a Specify the port for the agent to use (default 443)
	-x Specify an http proxy for the agent to use

	all flags:

	-P package file
	-T target volume
	-k activation key
	-i customerid
	-s server 
	-p protocol
	-a port
	-x proxy 
	EOF
}

if [ $(id -u) != '0' ] ; then
	usage
	echo ; echo "batch-install.sh Must be run as root" ; echo
	exit 1
fi

if [ -z "$package_file" ] || [ -z "$tgt_vol" ] ; then
	usage
	echo "No target volume or package file"
	exit 1
fi

decrypt_key() {
	
	DecryptedKey=$(echo $1 | openssl enc -base64 -d)
	if [ -z $DecryptedKey ]; then
		DecryptedKey=$(echo $1 | openssl enc -base64 -d -A)
	fi 
	#echo $DecryptedKey

	#### decrypted key format:  https://warsteiner.lab2.n-able.com:443|37683|1|0
	uri=$( echo -n $DecryptedKey | awk -F"|" '{print $1}' )
	APPLIANCE=$( echo -n $DecryptedKey | awk -F"|" '{print $2}')
	ApplianceType=$( echo -n $DecryptedKey | awk -F"|" '{print $3}' )
	PROTOCOL=$( echo -n $uri | awk -F":" '{print $1}')
	SERVER=$( echo -n $uri | awk -F":" '{print $2}' | sed -e 's!^//!!' )
	PORT=$( echo -n $uri | awk -F":" '{print $3}' )
	PORT=$( echo -n $PORT | awk -F"," '{print $1}' )
}

validate_command() {
	validate_command="sudo $package_file/Contents/Plugins/ActDlg.bundle/Contents/Resources/InitialValidate -s $SERVER -n $PORT -p $PROTOCOL "

	if [ ! -z $PROXY ] ; then
		validate_command=${validate_command}"-x $PROXY "
	fi

	if [ ! -z $CID ] || [ ! -z "$CNAME" ] ; then
		if  [ ! -z $CID ] ; then
        	validate_command=${validate_command}" -f /tmp/nagent.conf -i $CID -l /tmp/nagent_install_log"
		elif [ ! -z "$CNAME" ] ; then
			validate_command=${validate_command}" -f /tmp/nagent.conf -c "$CNAME" -l /tmp/nagent_install_log"
		fi
	else
		usage
		exit 1
	fi
}

validate_command_ativationkey() {
	# Prepare validate command with proper arguments
	validate_command="sudo $package_file/Contents/Plugins/ActDlg.bundle/Contents/Resources/InitialValidate -s $SERVER -n $PORT -p $PROTOCOL -a $APPLIANCE -f /tmp/nagent.conf -l /tmp/nagent_install_log"
	
	if [ ! -z $PROXY ] ; then
		validate_command=${validate_command}"-x $PROXY "
	fi
}

install() {
	echo $validate_command

	# Cleanup 
	`rm -f /tmp/nagent.conf`
	validate_rc=0
		
	# Run validate command and install upon success
	if $validate_command ; then		
		write_conf
		sudo installer -pkg $package_file -target "$tgt_vol"
	else
		validate_rc=$?
	fi
	
	# On failure display error message
	if [ $validate_rc -gt 0 ] ; then
		echo "Could not successfully self-register agent"
		case $validate_rc in 
			10)
				echo "Could not connect to N-central server";
				;;
			11)
				echo "Invalid Customer Name";
				;;
			12)
				echo "Invalid Customer ID";
				;;
			13)	
				echo "Invalid Appliance ID";
				;;
			14)
				echo "Local Asset Discovery failed, check /tmp/nagent_install_log for more details";
				;;
			15)
				echo "The N-central server cannot register the agent";
				;;
			16)
				echo "Unable to create Configuration file";
				;;
			17)
				echo "Unable to create log file";
				;;
			*)
				usage;
				echo "Unknown Error occured, check /tmp/nagent_install_log for more details";
				;;
		esac
	fi
	
	exit $validate_rc
}

write_conf() {
if [ x$1 = x"full" ] ; then 
        cat <<EOF >> /tmp/nagent.conf
[main]
    logfilename=/var/log/N-able/N-agent/nagent.log
    loglevel=2
    homedir=/Applications/N-agent/home/nagent/
    thread_limitation=50 
    poll_delay=1
    datablock_size=20

[soap]
    server=$SERVER
    applianceid=$APPLIANCE
    server_ro=no
    protocol=$PROTOCOL
    port=$PORT
EOF
	if [ ! -z $PROXY] ; then
		cat <<EOF >> /tmp/nagent.conf
    proxy=$PROXY
EOF
	fi

else 
	 cat <<EOF >> /tmp/nagent.conf
[main]
    logfilename=/var/log/N-able/N-agent/nagent.log
    loglevel=2
    homedir=/Applications/N-agent/home/nagent/
    thread_limitation=50 
    poll_delay=1
    datablock_size=20
EOF
fi
}

start_agent() {
	sudo launchctl load /Library/LaunchDaemons/com.n-able.agent-macosx.plist
}

if [ ! -z $ACTIVATE_KEY ] ; then 	
	decrypt_key $ACTIVATE_KEY
	validate_command_ativationkey
	install && start_agent
elif [ ! -z $SERVER ] ; then 
	validate_command
	install && start_agent
else
	usage
fi
